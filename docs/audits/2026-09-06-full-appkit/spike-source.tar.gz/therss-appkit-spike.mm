#import <AppKit/AppKit.h>
#import <objc/runtime.h>
#include <node_api.h>
#include <cstring>
#include <string>
static char key;
@interface TRNativeSpike : NSObject <NSTableViewDataSource,NSTableViewDelegate>
@property(nonatomic,weak) NSWindow *window;
@property(nonatomic,strong) NSView *original;
@property(nonatomic,strong) NSView *host;
@property(nonatomic,strong) NSSplitView *split;
@property(nonatomic,strong) NSTextField *query;
@property(nonatomic,strong) NSSecureTextField *secret;
@property(nonatomic,strong) NSButton *submit;
@property(nonatomic,strong) NSTableView *table;
@property(nonatomic,strong) NSTextView *reading;
@property(nonatomic) napi_threadsafe_function callback;
- (void)mount;
- (void)dispose;
@end
@interface TRNativeCanvas : NSView @end
@implementation TRNativeCanvas
- (BOOL)isFlipped { return YES; }
@end
@implementation TRNativeSpike
- (void)mount {
 self.original=self.window.contentView;
 self.host=[[TRNativeCanvas alloc] initWithFrame:self.original.frame];self.host.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
 [self.original removeFromSuperview];self.original.hidden=YES;[self.host addSubview:self.original];self.window.contentView=self.host;
 self.split=[[NSSplitView alloc] initWithFrame:self.host.bounds];self.split.vertical=YES;self.split.dividerStyle=NSSplitViewDividerStyleThin;self.split.autoresizingMask=NSViewWidthSizable|NSViewHeightSizable;
 NSGlassEffectView *glass=[[NSGlassEffectView alloc] initWithFrame:NSMakeRect(0,0,210,self.host.bounds.size.height)];
 TRNativeCanvas *side=[[TRNativeCanvas alloc] initWithFrame:glass.bounds];glass.contentView=side;
 NSTextField *brand=[NSTextField labelWithString:@"TheRSS · AppKit pilot"];brand.frame=NSMakeRect(18,58,180,24);brand.font=[NSFont boldSystemFontOfSize:14];[side addSubview:brand];
 NSArray *destinations=@[@"Discover",@"Saved",@"Data Analytics",@"Sources",@"Settings"];
 for(NSUInteger i=0;i<destinations.count;i++){NSButton *button=[NSButton buttonWithTitle:destinations[i] target:nil action:nil];button.frame=NSMakeRect(16,100+44*i,175,32);button.bezelStyle=NSBezelStyleRounded;[side addSubview:button];}
 TRNativeCanvas *content=[[TRNativeCanvas alloc] initWithFrame:NSMakeRect(211,0,self.host.bounds.size.width-211,self.host.bounds.size.height)];
 NSTextField *heading=[NSTextField labelWithString:@"Complete native interface spike"];heading.frame=NSMakeRect(24,58,700,32);heading.font=[NSFont boldSystemFontOfSize:23];[content addSubview:heading];
 NSTextField *label=[NSTextField labelWithString:@"Research question — native text input"];label.frame=NSMakeRect(24,112,500,22);[content addSubview:label];
 self.query=[[NSTextField alloc] initWithFrame:NSMakeRect(24,143,600,30)];self.query.placeholderString=@"边缘计算 / semantic communications";self.query.accessibilityLabel=@"Research question";[content addSubview:self.query];
 self.secret=[[NSSecureTextField alloc] initWithFrame:NSMakeRect(24,188,280,30)];self.secret.placeholderString=@"Protected credential (fixture only)";self.secret.accessibilityLabel=@"Protected credential";[content addSubview:self.secret];
 NSPopUpButton *runner=[[NSPopUpButton alloc] initWithFrame:NSMakeRect(320,188,180,30) pullsDown:NO];[runner addItemsWithTitles:@[@"Model provider",@"Codex CLI",@"Claude Code"]];[content addSubview:runner];
 self.submit=[NSButton buttonWithTitle:@"Search" target:self action:@selector(search:)];self.submit.frame=NSMakeRect(518,188,105,30);self.submit.bezelStyle=NSBezelStyleRounded;[content addSubview:self.submit];
 NSScrollView *rows=[[NSScrollView alloc] initWithFrame:NSMakeRect(24,244,600,180)];rows.hasVerticalScroller=YES;rows.borderType=NSBezelBorder;
 self.table=[[NSTableView alloc] initWithFrame:rows.bounds];NSTableColumn *column=[[NSTableColumn alloc] initWithIdentifier:@"title"];column.title=@"Native research list";column.width=560;[self.table addTableColumn:column];self.table.dataSource=self;self.table.delegate=self;self.table.rowHeight=36;rows.documentView=self.table;[content addSubview:rows];
 NSScrollView *textScroll=[[NSScrollView alloc] initWithFrame:NSMakeRect(24,450,600,250)];textScroll.hasVerticalScroller=YES;textScroll.borderType=NSBezelBorder;
 self.reading=[[NSTextView alloc] initWithFrame:textScroll.bounds];self.reading.editable=NO;self.reading.selectable=YES;self.reading.font=[NSFont systemFontOfSize:14];self.reading.textContainerInset=NSMakeSize(12,12);self.reading.autoresizingMask=NSViewWidthSizable;self.reading.textContainer.widthTracksTextView=YES;
 NSMutableString *text=[NSMutableString stringWithString:@"原生阅读区 — native selectable text\n\n"];
 for(int i=0;i<40;i++)[text appendFormat:@"%d. This long Unicode text is rendered by NSTextView, without a DOM or CSS layout.\n",i+1];self.reading.string=text;textScroll.documentView=self.reading;[content addSubview:textScroll];
 [self.split addSubview:glass];[self.split addSubview:content];[self.host addSubview:self.split];[self.split setPosition:210 ofDividerAtIndex:0];
 [self.window makeFirstResponder:self.query];
}
- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView { return 3; }
- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)column row:(NSInteger)row { return @[@"Structured pruning for edge deployment",@"语义通信与资源高效学习",@"Native scrolling and selection fixture"][row]; }
- (void)search:(id)sender {
 NSDictionary *event=@{@"action":@"search",@"query":self.query.stringValue,@"hasSecret":@(self.secret.stringValue.length>0)};
 NSData *data=[NSJSONSerialization dataWithJSONObject:event options:0 error:nil];auto text=new std::string((const char *)data.bytes,data.length);
 if(napi_call_threadsafe_function(self.callback,text,napi_tsfn_nonblocking)!=napi_ok)delete text;
}
- (void)dispose {
 self.secret.stringValue=@"";
 if(self.window.contentView==self.host){[self.original removeFromSuperview];self.original.hidden=NO;self.window.contentView=self.original;}
 if(self.callback){napi_release_threadsafe_function(self.callback,napi_tsfn_abort);self.callback=nullptr;}
}
@end
static napi_value fail(napi_env env,const char *message){napi_throw_error(env,nullptr,message);return nullptr;}
static NSWindow *windowFor(napi_env env,napi_value value){
 bool isBuffer=false;void *data=nullptr;size_t size=0;napi_is_buffer(env,value,&isBuffer);
 if(!isBuffer||napi_get_buffer_info(env,value,&data,&size)!=napi_ok||size!=sizeof(void *)||![NSThread isMainThread]){fail(env,"Invalid fixture window");return nil;}
 void *pointer=nullptr;std::memcpy(&pointer,data,size);
 for(NSWindow *window in NSApp.windows){TRNativeSpike *c=objc_getAssociatedObject(window,&key);if(pointer==(__bridge void *)window.contentView||(c&&pointer==(__bridge void *)c.original))return window;}
 fail(env,"Fixture window is unavailable");return nil;
}
static void invoke(napi_env env,napi_value callback,void *,void *data){auto text=static_cast<std::string *>(data);if(env&&callback){napi_value value,receiver,result;napi_create_string_utf8(env,text->c_str(),text->size(),&value);napi_get_undefined(env,&receiver);napi_call_function(env,receiver,callback,1,&value,&result);}delete text;}
static napi_value attach(napi_env env,napi_callback_info info){
 napi_value values[2],result;size_t count=2;napi_get_cb_info(env,info,&count,values,nullptr,nullptr);if(count!=2)return fail(env,"Invalid attach");NSWindow *window=windowFor(env,values[0]);if(!window)return nullptr;
 TRNativeSpike *c=[TRNativeSpike new];c.window=window;napi_threadsafe_function callback;napi_value resource;napi_create_string_utf8(env,"AppKitUIFixture",NAPI_AUTO_LENGTH,&resource);if(napi_create_threadsafe_function(env,values[1],nullptr,resource,32,1,nullptr,nullptr,nullptr,invoke,&callback)!=napi_ok)return fail(env,"Callback failed");
 c.callback=callback;[c mount];objc_setAssociatedObject(window,&key,c,OBJC_ASSOCIATION_RETAIN_NONATOMIC);napi_get_undefined(env,&result);return result;
}
static napi_value inspect(napi_env env,napi_callback_info info){
 napi_value value,result;size_t count=1;napi_get_cb_info(env,info,&count,&value,nullptr,nullptr);NSWindow *w=windowFor(env,value);if(!w)return nullptr;TRNativeSpike *c=objc_getAssociatedObject(w,&key);
 NSDictionary *snapshot=@{@"windowNumber":@(w.windowNumber),@"nativeRoot":NSStringFromClass(w.contentView.class),@"webHidden":@(c.original.hidden),@"split":NSStringFromClass(c.split.class),@"query":NSStringFromClass(c.query.class),@"secret":NSStringFromClass(c.secret.class),@"table":NSStringFromClass(c.table.class),@"reading":NSStringFromClass(c.reading.class),@"selectedRow":@(c.table.selectedRow),@"sidebarWidth":@(c.split.subviews.firstObject.frame.size.width),@"textLength":@(c.reading.string.length),@"secretValue":@"redacted",@"queryValue":c.query.stringValue};
 NSData *json=[NSJSONSerialization dataWithJSONObject:snapshot options:0 error:nil];napi_create_string_utf8(env,(const char *)json.bytes,json.length,&result);return result;
}
static napi_value exercise(napi_env env,napi_callback_info info){
 napi_value value,result;size_t count=1;napi_get_cb_info(env,info,&count,&value,nullptr,nullptr);NSWindow *w=windowFor(env,value);if(!w)return nullptr;TRNativeSpike *c=objc_getAssociatedObject(w,&key);c.query.stringValue=@"边缘计算 🔬 native UI";[c.table selectRowIndexes:[NSIndexSet indexSetWithIndex:1] byExtendingSelection:NO];[c.split setPosition:240 ofDividerAtIndex:0];c.secret.stringValue=@"fixture-only-secret";[c.submit performClick:nil];napi_get_boolean(env,true,&result);return result;
}
static napi_value detach(napi_env env,napi_callback_info info){napi_value value,result;size_t count=1;napi_get_cb_info(env,info,&count,&value,nullptr,nullptr);NSWindow *w=windowFor(env,value);if(!w)return nullptr;TRNativeSpike *c=objc_getAssociatedObject(w,&key);[c dispose];objc_setAssociatedObject(w,&key,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC);napi_get_undefined(env,&result);return result;}
static napi_value init(napi_env env,napi_value exports){napi_property_descriptor m[]={{"attach",0,attach,0,0,0,napi_default,0},{"inspect",0,inspect,0,0,0,napi_default,0},{"exercise",0,exercise,0,0,0,napi_default,0},{"detach",0,detach,0,0,0,napi_default,0}};napi_define_properties(env,exports,4,m);return exports;}
NAPI_MODULE(NODE_GYP_MODULE_NAME,init)
