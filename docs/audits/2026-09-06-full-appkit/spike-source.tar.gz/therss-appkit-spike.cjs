const {app,BrowserWindow}=require('electron')
const fs=require('node:fs')
const os=require('node:os'),path=require('node:path'),cp=require('node:child_process')
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'therss-appkit-host-spike-'));app.setPath('userData',profile)
app.whenReady().then(async()=>{
 const window=new BrowserWindow({width:1140,height:820,title:'TheRSS native-only architecture spike',titleBarStyle:'hiddenInset',show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}})
 await window.loadURL('data:text/html,<html><body></body></html>')
 const native=require('/private/tmp/therss-appkit-spike.node'),events=[]
 native.attach(window.getNativeWindowHandle(),value=>events.push(JSON.parse(value)))
 window.show();window.focus()
 native.exercise(window.getNativeWindowHandle())
 setTimeout(async()=>{
  const state=JSON.parse(native.inspect(window.getNativeWindowHandle()))
  const proof={state,events,webElementCount:await window.webContents.executeJavaScript('document.body.children.length')}
  fs.writeFileSync('/private/tmp/therss-appkit-spike-result.json',JSON.stringify(proof,null,2))
  console.log(JSON.stringify(proof))
  cp.execFileSync('python3',['/Users/dtjgp/.codex/skills/screenshot/scripts/take_screenshot.py','--window-id',String(state.windowNumber),'--path','/private/tmp/therss-appkit-spike.png'])
  native.detach(window.getNativeWindowHandle());window.destroy();app.quit()
 },500)
 setTimeout(()=>app.quit(),30000)
})
