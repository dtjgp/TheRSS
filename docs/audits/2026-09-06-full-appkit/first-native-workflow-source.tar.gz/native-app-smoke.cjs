const {createRequire}=require('node:module');const r=createRequire('/Users/dtjgp/Projects/TheRSS/package.json');
const { _electron: electron }=r('@playwright/test');const fs=require('node:fs/promises');const os=require('node:os');const path=require('node:path');const cp=require('node:child_process');
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function find(node,id){if(!node)return null;if(node.id===id)return node;for(const c of node.children||[]){const x=find(c,id);if(x)return x}return null}
(async()=>{
 const profile=await fs.mkdtemp(path.join(os.tmpdir(),'therss-appkit-integration-'));
 const app=await electron.launch({args:[`--user-data-dir=${profile}`,'/Users/dtjgp/Projects/TheRSS'],env:{...process.env,THERSS_E2E_FIXTURES:'1',THERSS_UI:'appkit'},timeout:30000});
 const errors=[];app.process().stderr.on('data',x=>errors.push(String(x)));
 try{
  const page=await app.firstWindow();await page.waitForLoadState();
  await app.evaluate(async({BrowserWindow})=>{const{createRequire}=process.getBuiltinModule('node:module');globalThis.__nativeBridge=createRequire('/Users/dtjgp/Projects/TheRSS/package.json')('/Users/dtjgp/Projects/TheRSS/out/native-appkit/therss-ui.node');globalThis.__nativeWindow=BrowserWindow.getAllWindows()[0]});
  const inspect=()=>app.evaluate(()=>JSON.parse(globalThis.__nativeBridge.inspect(globalThis.__nativeWindow.getNativeWindowHandle())));
  const act=(id,action,value,extra={})=>app.evaluate((_,data)=>globalThis.__nativeBridge.interactFixture(globalThis.__nativeWindow.getNativeWindowHandle(),JSON.stringify(data)),{id,action,...(value!==undefined?{value}:{}),...extra});
  const wait=async(id,condition=x=>!!x)=>{for(let i=0;i<200;i++){let s;try{s=await inspect()}catch(e){if(!String(e).includes('detached'))throw e;await delay(100);continue}const node=find(s.root,id)||find(s.modal,id);if(condition(node))return s;await delay(100)}throw Error('Native wait failed: '+id)};
  await wait('discover-query');
  if(await page.evaluate(()=>document.body.childElementCount)!==0)throw Error('Native route contains Web UI');
  await act('discover-query','fill','边缘计算 structured pruning');await act('discover-runner','choose','codex');await delay(50);await act('discover-search','click');
  await wait('discover-results');
  await act('discover-save','click');await delay(120);await act('discover-analyze','click');await wait('discover-analysis');
  await act('discover-details','click');await wait('document-modal-content');await act('modal-close','click');await delay(100);
  await act('navigate-saved','click');await wait('saved-items');
  await act('navigate-settings','click');await wait('personal-prompt');await act('personal-prompt','fill','资源高效 AI 与边缘智能');await act('personal-save','click');await delay(100);
  await act('settings-tab','choose','provider');await wait('provider-name');await act('provider-name','fill','Native fixture');await act('provider-url','fill','https://fixture.invalid/v1');await act('provider-model','fill','fixture-model');await act('provider-save','click');await delay(150);
  await act('navigate-analytics','click');await wait('analytics-analyses');
  const analytics=await inspect();const analysis=find(analytics.root,'analytics-analyses').rows[0];await act('analytics-analyses','select',analysis.id);await wait('analytics-analysis-content');
  await act('navigate-sources','click');await wait('sources-list');await act('sources-list','select','folo:302',{activate:true});await wait('source-content-items');
  await act('open-local-search','click');await wait('local-search-query');await act('local-search-query','fill','pruning');await act('local-search-submit','click');await wait('local-search-results');await act('modal-close','click');await delay(100);
  await act('navigate-discover','click');await wait('discover-results');
  await act('discover-promote','click');await wait('promotion-confirm');await act('promotion-confirm','click');await wait('promotion-receipt-text');await act('modal-close','click');await delay(200);
  const final=await inspect();await fs.writeFile('/private/tmp/therss-native-app-result.json',JSON.stringify({ok:true,profile,webElementCount:await page.evaluate(()=>document.body.childElementCount),final,errors},null,2));
  cp.execFileSync('/usr/sbin/screencapture',['-x','-l',String(final.windowNumber),'/private/tmp/therss-native-app.png']);
  console.log(JSON.stringify({ok:true,profile,windowNumber:final.windowNumber,sourceRows:find(final.root,'discover-results').rows.length,errors}));
 }catch(e){try{await fs.writeFile('/private/tmp/therss-native-app-failure.json',JSON.stringify({error:String(e),errors,state:await app.evaluate(()=>JSON.parse(globalThis.__nativeBridge.inspect(globalThis.__nativeWindow.getNativeWindowHandle())))},null,2))}catch{};throw e}
 finally{await app.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
